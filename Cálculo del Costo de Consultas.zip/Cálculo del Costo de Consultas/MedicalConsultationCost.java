import java.util.InputMismatchException;
import java.util.Scanner;

public class MedicalConsultationCost {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int consultationNumber = 0;
        int totalCost = 0;
        int currentCost = 0;

        // Solicitar número de cita
        while (true) {
            try {
                System.out.print("Ingrese el número de cita actual: ");
                consultationNumber = scanner.nextInt();
                if (consultationNumber >= 1) break;
                System.out.println("Error: El número de cita debe ser mayor o igual a 1.");
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número válido.");
                scanner.next();
            }
        }

        // Calcular costo de la cita actual
        if (consultationNumber <= 3) {
            currentCost = 200000;
        } else if (consultationNumber <= 5) {
            currentCost = 150000;
        } else if (consultationNumber <= 8) {
            currentCost = 100000;
        } else {
            currentCost = 50000;
        }

        // Calcular costo total de todas las citas hasta la actual
        for (int i = 1; i <= consultationNumber; i++) {
            if (i <= 3) {
                totalCost += 200000;
            } else if (i <= 5) {
                totalCost += 150000;
            } else if (i <= 8) {
                totalCost += 100000;
            } else {
                totalCost += 50000;
            }
        }

        // Mostrar resultados
        System.out.printf("El costo de la cita actual es: $%,d\n", currentCost);
        System.out.printf("El total pagado hasta ahora es: $%,d\n", totalCost);

        scanner.close();
    }
}
