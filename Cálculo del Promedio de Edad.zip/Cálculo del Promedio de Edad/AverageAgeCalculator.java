import java.util.InputMismatchException;
import java.util.Scanner;

public class AverageAgeCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int numberOfStudents = 0;
        
        // Solicitar la cantidad de alumnos
        while (true) {
            try {
                System.out.print("Ingrese la cantidad de alumnos: ");
                numberOfStudents = scanner.nextInt();
                if (numberOfStudents > 0) break;
                System.out.println("Error: La cantidad de alumnos debe ser mayor que cero.");
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número entero válido.");
                scanner.next(); // Limpiar buffer de entrada
            }
        }
        
        int totalAge = 0;
        
        // Ingresar edades de los alumnos
        for (int i = 1; i <= numberOfStudents; i++) {
            while (true) {
                try {
                    System.out.print("Ingrese la edad del alumno " + i + ": ");
                    int age = scanner.nextInt();
                    if (age > 0) {
                        totalAge += age;
                        break;
                    }
                    System.out.println("Error: La edad debe ser un número positivo.");
                } catch (InputMismatchException e) {
                    System.out.println("Error: Ingrese un número entero válido.");
                    scanner.next(); // Limpiar buffer de entrada
                }
            }
        }
        
        // Calcular y mostrar el promedio de edad
        double averageAge = (double) totalAge / numberOfStudents;
        System.out.printf("La edad promedio del grupo es: %.2f años\n", averageAge);
        
        scanner.close();
    }
}
