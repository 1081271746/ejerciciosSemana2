import java.util.InputMismatchException;
import java.util.Scanner;

public class WeeklySalaryCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double hoursWorked = 0;
        double hourlyRate = 0;
        double weeklySalary = 0;

        // Solicitar cantidad de horas trabajadas
        while (true) {
            try {
                System.out.print("Ingrese la cantidad de horas trabajadas en la semana: ");
                hoursWorked = scanner.nextDouble();
                if (hoursWorked > 0) break;
                System.out.println("Error: Las horas trabajadas deben ser mayores que cero.");
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número válido.");
                scanner.next();
            }
        }

        // Solicitar pago por hora
        while (true) {
            try {
                System.out.print("Ingrese el pago por hora: ");
                hourlyRate = scanner.nextDouble();
                if (hourlyRate > 0) break;
                System.out.println("Error: El pago por hora debe ser mayor que cero.");
            } catch (InputMismatchException e) {
                System.out.println("Error: Ingrese un número válido.");
                scanner.next();
            }
        }

        // Calcular sueldo semanal
        weeklySalary = hoursWorked * hourlyRate;
        
        // Mostrar resultado
        System.out.printf("El sueldo semanal a recibir es: $%.2f\n", weeklySalary);

        scanner.close();
    }
}
